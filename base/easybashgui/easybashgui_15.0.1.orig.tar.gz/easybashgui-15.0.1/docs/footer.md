Made with love by [Vittorio Cagnetta](https://sites.google.com/site/vaisarger/) under GPLv3 License
