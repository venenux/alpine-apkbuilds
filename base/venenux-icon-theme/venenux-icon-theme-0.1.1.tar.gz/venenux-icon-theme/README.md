# venenux-icon-theme

16-bit style icon theme for minimalist distros **forked from pixelitos-icon-theme**

* https://github.com/itzselenux/pixelitos-icon-theme
* https://github.com/itzselenux/ilustraciones-icon-theme

<img src="https://itszariep.codeberg.page/projects/pixelitos-icon-theme/1.webp" width="320px" alt="pixelitos" />

## Preview

You can preview pixelitos icons on their [website](https://itszariep.codeberg.page/projects/pixelitos-icon-theme/icons/)

## Installation

You can use packages from Open Suse Build service with support for Debian and Alpine now! at [![build result](https://build.opensuse.org/projects/home:venenux:alpinecores/packages/venenux-icon-theme/badge.svg?type=default)](https://build.opensuse.org/package/show/home:venenux:alpinecores/venenux-icon-theme)

https://software.opensuse.org//download.html?project=home%3Avenenux%3Aalpinecores&package=venenux-icon-theme

You can automatically use the install scrip, first be sure ImageMagick is installed, and later run following commands:

```bash
git clone https://github.com/ItzSelenux/pixelitos-icon-theme

cd pixelitos-icon-theme

PREFIX=/usr DESTDIR=/ ./install.sh
```

> [!Note]
> Due to space problems in the repository, it only contains the 16x16 icons, so the 128x128 icons (which display correctly in the apps) need to be generated with ImageMagick. 

Manual method can be done using following commands:

```
cd pixelitos-icon-theme

./compile-icons.sh

cd ../

mv pixelitos-icon-theme ~/.local/share/icons/pixelitos
```


### Folder colors

You can choose a folder color by copying the content of a folder from `folder-colors/color` using `folders-color.sh`

```
./folder-colors.sh
```

Colors setup can be made by using the `colors.sh` script, edit and setup new colors with it.
