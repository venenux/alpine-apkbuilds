#!/bin/sh
set -e

DESDIRD="/"
PREFIXD="/usr/local"

DESTDIR=${DESTDIR:-$DESDIRD}
PREFIX=${PREFIX:-$PREFIXD}
INSTDIR="$DESTDIR$PREFIX/share"
EUIDR=$(id -u)


install_pixelitos_theme() {

        if [ "$EUIDR" != 0 ]; then
           echo "System install is not possible, not root, using XDG dir for..."
            INSTDIR="${XDG_DATA_HOME:-${HOME}/.local/share}"
            DIR="$INSTDIR/icons/venenux/"
            ICON_FOLDER="${DIR}/128"
        else
            DIR="$INSTDIR/icons/venenux/"
            ICON_FOLDER="${DIR}/128"
        fi

	echo "Creating theme directory: ${DIR} (use PREFIX and DESTDIR to change)"
	mkdir -p "${DIR}"

	if [ ! -d "${ICON_FOLDER}" ]; then
		echo "'128' folder does not exist. Compiling icons..."
		compile_icons
	fi

	cp -r 128 16 index.theme README.md "${DIR}"
	if [ $? -eq 0 ]; then
		echo "Installation successful! ($DIR)"
		rm -rf 128
	else
		echo "Error: Failed to copy files."
		exit 1
	fi
}

compile_icons() {
	echo "Compiling 128x128 icons..."
	if ./compile-icons.sh; then
		echo "Icons compiled successfully!"
	else
		echo "Error: Failed to compile icons, if you cloned from git, rebase please."
		exit 1
	fi
}

install_pixelitos_theme
